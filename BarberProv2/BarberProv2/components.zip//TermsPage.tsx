import { FileText, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface TermsPageProps {
  onNavigate: (page: string) => void;
}

export function TermsPage({ onNavigate }: TermsPageProps) {
  return (
    <div className="min-h-screen bg-[#0D0D0D] pt-32 pb-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <Button
          onClick={() => onNavigate('home')}
          variant="ghost"
          className="text-[#C19A6B] hover:text-[#EAB308] mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Início
        </Button>

        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-lg flex items-center justify-center">
            <FileText className="w-6 h-6 text-[#0D0D0D]" />
          </div>
          <h1 
            className="text-4xl md:text-5xl text-white"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            Termos de Uso
          </h1>
        </div>

        <p className="text-white/60 text-lg mb-8">
          Última atualização: 10 de Janeiro de 2025
        </p>

        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
          <div className="prose prose-invert max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">1. Aceitação dos Termos</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Ao acessar e usar o BarberPro, você concorda em cumprir e estar vinculado a estes Termos de Uso. 
                Se você não concordar com qualquer parte destes termos, não use nosso serviço.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">2. Descrição do Serviço</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                O BarberPro é uma plataforma de gestão para barbearias que permite:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Agendamento de horários</li>
                <li>Controle de pagamentos</li>
                <li>Gestão de clientes</li>
                <li>Relatórios e métricas</li>
                <li>Comunicação via WhatsApp</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">3. Cadastro e Conta</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Para utilizar o BarberPro, você deve:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Fornecer informações verdadeiras e atualizadas</li>
                <li>Manter a segurança de sua senha</li>
                <li>Notificar imediatamente sobre uso não autorizado</li>
                <li>Ser responsável por todas as atividades em sua conta</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">4. Uso Aceitável</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Você concorda em NÃO:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Usar o serviço para fins ilegais</li>
                <li>Transmitir vírus ou códigos maliciosos</li>
                <li>Tentar acessar contas de outros usuários</li>
                <li>Interferir no funcionamento do serviço</li>
                <li>Coletar dados de outros usuários sem permissão</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">5. Planos e Pagamentos</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                <strong className="text-[#EAB308]">Teste Grátis:</strong> Oferecemos 7 dias de teste gratuito para novos usuários.
              </p>
              <p className="text-white/80 leading-relaxed mb-4">
                <strong className="text-[#EAB308]">Planos Pagos:</strong>
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Mensal: R$ 20,00/mês</li>
                <li>Anual: R$ 499,00/ano (economia de 2 meses)</li>
              </ul>
              <p className="text-white/80 leading-relaxed mb-4">
                <strong className="text-[#EAB308]">Renovação:</strong> Todos os planos são renovados automaticamente, 
                a menos que cancelados antes do final do período.
              </p>
              <p className="text-white/80 leading-relaxed mb-4">
                <strong className="text-[#EAB308]">Reembolso:</strong> Não oferecemos reembolsos para períodos já pagos, 
                mas você pode cancelar a qualquer momento para evitar cobranças futuras.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">6. Propriedade Intelectual</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Todo o conteúdo, design, funcionalidades e código do BarberPro são propriedade exclusiva 
                da nossa empresa e protegidos por leis de direitos autorais.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">7. Limitação de Responsabilidade</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                O BarberPro é fornecido "como está". Não garantimos que o serviço será ininterrupto ou livre de erros. 
                Não somos responsáveis por:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Perda de dados ou lucros</li>
                <li>Interrupções no serviço</li>
                <li>Erros ou inexatidões no conteúdo</li>
                <li>Danos indiretos ou consequenciais</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">8. Modificações do Serviço</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Reservamos o direito de modificar, suspender ou descontinuar qualquer parte do BarberPro 
                a qualquer momento, com ou sem aviso prévio.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">9. Rescisão</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Podemos encerrar ou suspender sua conta imediatamente, sem aviso prévio, se você violar 
                estes Termos de Uso.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">10. Lei Aplicável</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Estes termos são regidos pelas leis do Brasil. Qualquer disputa será resolvida nos 
                tribunais brasileiros.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">11. Contato</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Para dúvidas sobre estes Termos de Uso, entre em contato:
              </p>
              <ul className="list-none text-white/80 space-y-2 mb-4">
                <li>📧 Email: contato@barberpro.com</li>
                <li>📱 Telefone: (11) 98765-4321</li>
                <li>📍 Endereço: São Paulo, SP</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">12. Alterações nos Termos</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Podemos atualizar estes Termos de Uso periodicamente. Notificaremos você sobre mudanças 
                significativas por email ou através da plataforma.
              </p>
              <p className="text-white/80 leading-relaxed">
                O uso continuado do serviço após as alterações constitui aceitação dos novos termos.
              </p>
            </section>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <Button
            onClick={() => onNavigate('home')}
            className="bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90"
          >
            Voltar ao Início
          </Button>
        </div>
      </div>
    </div>
  );
}
