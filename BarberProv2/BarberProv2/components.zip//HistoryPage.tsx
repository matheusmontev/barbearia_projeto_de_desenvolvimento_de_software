import { RefreshCw, History as HistoryIcon, Calendar, User, Scissors, Clock, DollarSign } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { serviceValues, type Appointment } from "../services/api";

interface HistoryPageProps {
  appointments: Appointment[];
  canceledAppointments: Appointment[];
  isLoading: boolean;
  onRefresh: () => void;
}

export function HistoryPage({ appointments, canceledAppointments, isLoading, onRefresh }: HistoryPageProps) {
  const allAppointments = [...appointments, ...canceledAppointments].sort((a, b) => {
    // Sort by most recent
    const dateA = new Date(a.createdAt || 0);
    const dateB = new Date(b.createdAt || 0);
    return dateB.getTime() - dateA.getTime();
  });

  const activeCount = appointments.length;
  const canceledCount = canceledAppointments.length;
  const totalCount = allAppointments.length;

  const getTotalRevenue = (appts: Appointment[]) => {
    return appts
      .filter(apt => apt.paid)
      .reduce((sum, apt) => sum + apt.value, 0);
  };

  const renderTable = (appts: Appointment[], showCanceledDate: boolean = false) => {
    if (appts.length === 0) {
      return (
        <div className="text-center py-12">
          <HistoryIcon className="w-16 h-16 text-white/20 mx-auto mb-4" />
          <p className="text-white/60">Nenhum agendamento encontrado</p>
        </div>
      );
    }

    return (
      <Table>
        <TableHeader>
          <TableRow className="border-[#C19A6B]/20 hover:bg-transparent">
            <TableHead className="text-[#EAB308]">Cliente</TableHead>
            <TableHead className="text-[#EAB308]">Serviço</TableHead>
            <TableHead className="text-[#EAB308]">Dia</TableHead>
            <TableHead className="text-[#EAB308]">Horário</TableHead>
            <TableHead className="text-[#EAB308]">Valor</TableHead>
            <TableHead className="text-[#EAB308]">Pagamento</TableHead>
            <TableHead className="text-[#EAB308]">Status</TableHead>
            {showCanceledDate && <TableHead className="text-[#EAB308]">Cancelado em</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {appts.map((apt) => (
            <TableRow key={apt._id} className="border-[#C19A6B]/10 hover:bg-[#C19A6B]/5">
              <TableCell className={apt.canceledAt ? "text-white/60" : "text-white"}>
                {apt.client}
              </TableCell>
              <TableCell className={apt.canceledAt ? "text-white/50" : "text-white/80"}>
                {apt.service}
              </TableCell>
              <TableCell className={apt.canceledAt ? "text-white/50" : "text-white/80"}>
                {apt.day}
              </TableCell>
              <TableCell className={apt.canceledAt ? "text-white/50" : "text-white/80"}>
                {apt.time}
              </TableCell>
              <TableCell className={apt.canceledAt ? "text-white/50" : "text-white/80"}>
                R$ {apt.value}
              </TableCell>
              <TableCell>
                <Badge className={`${
                  apt.paid
                    ? 'bg-[#25D366]/20 text-[#25D366] border-[#25D366]/30'
                    : 'bg-[#DC2626]/20 text-[#DC2626] border-[#DC2626]/30'
                }`}>
                  {apt.paid ? '✓ Pago' : '✗ Não Pago'}
                </Badge>
              </TableCell>
              <TableCell>
                {apt.canceledAt ? (
                  <Badge className="bg-[#DC2626]/20 text-[#DC2626] border-[#DC2626]/30">
                    Cancelado
                  </Badge>
                ) : (
                  <Badge className="bg-[#25D366]/20 text-[#25D366] border-[#25D366]/30">
                    Ativo
                  </Badge>
                )}
              </TableCell>
              {showCanceledDate && apt.canceledAt && (
                <TableCell className="text-white/50">
                  {new Date(apt.canceledAt).toLocaleString('pt-BR')}
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] pt-40 pb-20 px-4">
      <div className="container mx-auto">
        <div className="mb-12 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-lg flex items-center justify-center">
              <HistoryIcon className="w-6 h-6 text-[#0D0D0D]" />
            </div>
            <div>
              <h1 
                className="text-4xl md:text-5xl text-white"
                style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
              >
                Histórico de Agendamentos
              </h1>
              <p className="text-xl text-white/60">
                Visualize todos os seus agendamentos
              </p>
            </div>
          </div>
          <Button
            onClick={onRefresh}
            variant="outline"
            className="border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10"
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Total de Agendamentos</p>
                <p className="text-3xl text-white">{totalCount}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-[#EAB308]" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Agendamentos Ativos</p>
                <p className="text-3xl text-white">{activeCount}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#25D366]/20 to-[#25D366]/10 rounded-lg flex items-center justify-center">
                <User className="w-6 h-6 text-[#25D366]" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Cancelados</p>
                <p className="text-3xl text-white">{canceledCount}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#DC2626]/20 to-[#DC2626]/10 rounded-lg flex items-center justify-center">
                <Scissors className="w-6 h-6 text-[#DC2626]" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Receita (Pagos)</p>
                <p className="text-3xl text-white">R$ {getTotalRevenue(appointments).toLocaleString('pt-BR')}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-[#EAB308]" />
              </div>
            </div>
          </Card>
        </div>

        {/* Tabs for filtering */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="bg-[#1A1A1A] border border-[#C19A6B]/20 mb-6">
            <TabsTrigger 
              value="all"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#C19A6B] data-[state=active]:to-[#EAB308] data-[state=active]:text-[#0D0D0D]"
            >
              Todos ({totalCount})
            </TabsTrigger>
            <TabsTrigger 
              value="active"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#C19A6B] data-[state=active]:to-[#EAB308] data-[state=active]:text-[#0D0D0D]"
            >
              Ativos ({activeCount})
            </TabsTrigger>
            <TabsTrigger 
              value="canceled"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#C19A6B] data-[state=active]:to-[#EAB308] data-[state=active]:text-[#0D0D0D]"
            >
              Cancelados ({canceledCount})
            </TabsTrigger>
          </TabsList>

          {/* All Appointments */}
          <TabsContent value="all">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h2 className="text-2xl text-white mb-6">Todos os Agendamentos</h2>
              {renderTable(allAppointments, false)}
            </Card>
          </TabsContent>

          {/* Active Appointments */}
          <TabsContent value="active">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h2 className="text-2xl text-white mb-6">Agendamentos Ativos</h2>
              {renderTable(appointments, false)}
            </Card>
          </TabsContent>

          {/* Canceled Appointments */}
          <TabsContent value="canceled">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h2 className="text-2xl text-white mb-6">Agendamentos Cancelados</h2>
              {renderTable(canceledAppointments, true)}
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
