import { Check, Zap, Crown } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface PricingPageProps {
  onNavigate: (page: string) => void;
}

export function PricingPage({ onNavigate }: PricingPageProps) {
  return (
    <div className="min-h-screen bg-[#0D0D0D] pt-40 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h1 
            className="text-4xl md:text-5xl text-white mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            Planos que Cabem no Seu Bolso
          </h1>
          <p className="text-xl text-white/60 mb-6">
            Escolha o melhor plano para sua barbearia e comece seu teste grátis
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#25D366]/20 to-[#25D366]/10 border border-[#25D366]/30 rounded-full">
            <span className="text-[#25D366]">🎉 7 dias de teste grátis em qualquer plano</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Monthly Plan */}
          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 hover:border-[#C19A6B]/40 transition-all">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-[#EAB308]" />
              </div>
              <div>
                <h3 className="text-2xl text-white">Plano Mensal</h3>
                <p className="text-white/60 text-sm">Flexibilidade total</p>
              </div>
            </div>

            <div className="mb-6">
              <div className="flex items-baseline gap-2">
                <span className="text-5xl text-white" style={{ fontWeight: 700 }}>R$ 20</span>
                <span className="text-white/60">/mês</span>
              </div>
              <p className="text-white/50 text-sm mt-2">Cancele quando quiser</p>
            </div>

            <ul className="space-y-4 mb-8">
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Agendamentos ilimitados</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Notificações automáticas via WhatsApp</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Controle de pagamentos</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Relatórios de desempenho</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Agenda compartilhável</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Suporte prioritário</span>
              </li>
            </ul>

            <Button
              onClick={() => onNavigate('signup')}
              className="w-full bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full py-6"
            >
              Começar Teste Grátis
            </Button>
          </Card>

          {/* Annual Plan */}
          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#EAB308] p-8 relative hover:border-[#EAB308] transition-all">
            <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] border-0 px-4 py-1">
              MAIS POPULAR - Economize 79%
            </Badge>

            <div className="flex items-center gap-3 mb-6 mt-2">
              <div className="w-12 h-12 bg-gradient-to-br from-[#EAB308] to-[#C19A6B] rounded-lg flex items-center justify-center">
                <Crown className="w-6 h-6 text-[#0D0D0D]" />
              </div>
              <div>
                <h3 className="text-2xl text-white">Plano Anual</h3>
                <p className="text-white/60 text-sm">Melhor custo-benefício</p>
              </div>
            </div>

            <div className="mb-6">
              <div className="flex items-baseline gap-2">
                <span className="text-5xl text-white" style={{ fontWeight: 700 }}>R$ 499</span>
                <span className="text-white/60">/ano</span>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-[#25D366]">R$ 41,58/mês</span>
                <Badge className="bg-[#25D366]/20 text-[#25D366] border-[#25D366]/30">
                  Economize R$ 241/ano
                </Badge>
              </div>
            </div>

            <ul className="space-y-4 mb-8">
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Agendamentos ilimitados</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Notificações automáticas via WhatsApp</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Controle de pagamentos</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Relatórios de desempenho</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Agenda compartilhável</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#25D366] flex-shrink-0 mt-0.5" />
                <span className="text-white/80">Suporte prioritário VIP</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#EAB308] flex-shrink-0 mt-0.5" />
                <span className="text-white">
                  <strong>Bônus:</strong> Consultoria gratuita de configuração
                </span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-[#EAB308] flex-shrink-0 mt-0.5" />
                <span className="text-white">
                  <strong>Bônus:</strong> Acesso antecipado a novas funcionalidades
                </span>
              </li>
            </ul>

            <Button
              onClick={() => onNavigate('signup')}
              className="w-full bg-gradient-to-r from-[#EAB308] to-[#C19A6B] text-[#0D0D0D] hover:opacity-90 rounded-full py-6"
            >
              Começar Teste Grátis
            </Button>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <h2 className="text-3xl text-white text-center mb-12" style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}>
            Dúvidas Frequentes sobre Planos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h4 className="text-white mb-3">Como funciona o teste grátis?</h4>
              <p className="text-white/60 text-sm">
                Você tem 7 dias para testar todas as funcionalidades sem custos. Não é necessário cartão de crédito. Após o período, escolha o plano que preferir.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h4 className="text-white mb-3">Posso mudar de plano depois?</h4>
              <p className="text-white/60 text-sm">
                Sim! Você pode fazer upgrade do mensal para anual a qualquer momento e aproveitar a economia.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h4 className="text-white mb-3">Como funciona o pagamento?</h4>
              <p className="text-white/60 text-sm">
                Aceitamos pagamentos via PIX, cartão de crédito e boleto. O plano anual pode ser parcelado em até 12x.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
              <h4 className="text-white mb-3">Posso cancelar quando quiser?</h4>
              <p className="text-white/60 text-sm">
                Sim! Não há fidelidade. Você pode cancelar sua assinatura a qualquer momento sem custos adicionais.
              </p>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-20 text-center">
          <Card className="bg-gradient-to-r from-[#C19A6B]/10 to-[#EAB308]/10 border-[#C19A6B]/30 p-12 max-w-3xl mx-auto">
            <h3 className="text-3xl text-white mb-4" style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}>
              Pronto para modernizar sua barbearia?
            </h3>
            <p className="text-white/70 mb-6">
              Junte-se a centenas de barbeiros que já otimizaram suas agendas com o BarberPro
            </p>
            <Button
              onClick={() => onNavigate('signup')}
              className="bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full px-8 py-6 text-lg"
            >
              Começar Teste Grátis Agora
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
