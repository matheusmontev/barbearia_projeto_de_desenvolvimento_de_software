import React from "react";
import { Calendar, TrendingUp, Users, DollarSign, Clock, RefreshCw, Plus } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { AddAppointmentDialog } from "./AddAppointmentDialog";
import { toast } from "sonner@2.0.3";
import { 
  togglePaymentStatus as apiTogglePayment, 
  cancelAppointment as apiCancelAppointment,
  sendWhatsApp,
  serviceValues,
  type Appointment 
} from "../services/api";

const weekDays = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
const timeSlots = ["09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00", "18:00"];

// Safe way to access env variables with fallback
const getEnvVar = (key: string, defaultValue: string): string => {
  try {
    return import.meta?.env?.[key] || defaultValue;
  } catch {
    return defaultValue;
  }
};

// Configuration - Can be updated via .env file
const WHATSAPP_NUMBER = getEnvVar('VITE_WHATSAPP_NUMBER', '+5511987654321');
const PIX_KEY = getEnvVar('VITE_PIX_KEY', 'seuemail@gmail.com');

interface DashboardPageProps {
  appointments: Appointment[];
  isLoading: boolean;
  onRefresh: () => void;
}

export function DashboardPage({ appointments, isLoading, onRefresh }: DashboardPageProps) {
  const [selectedDay, setSelectedDay] = React.useState("Segunda");
  const [showAddDialog, setShowAddDialog] = React.useState(false);
  const [processingIds, setProcessingIds] = React.useState<Set<string>>(new Set());

  // Calculate metrics
  const totalCuts = appointments.filter(apt => apt.status === 'confirmed').length;
  
  const totalRevenue = appointments
    .filter(apt => apt.paid)
    .reduce((sum, apt) => sum + apt.value, 0);
  
  const uniqueClients = new Set(appointments.map(apt => apt.client)).size;
  
  // Calculate occupancy rate (considering 9 slots per day, 6 days a week = 54 total slots)
  const totalSlots = 9 * 6;
  const occupiedSlots = appointments.length;
  const occupancyRate = totalSlots > 0 ? Math.round((occupiedSlots / totalSlots) * 100) : 0;
  
  // Find busiest hour
  const hourCounts: { [key: string]: number } = {};
  appointments.forEach(apt => {
    hourCounts[apt.time] = (hourCounts[apt.time] || 0) + 1;
  });
  const busiestHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "N/A";
  
  // Calculate growth (simulated - comparing to previous month)
  const currentMonthCuts = totalCuts;
  const previousMonthCuts = Math.max(Math.round(currentMonthCuts * 0.88), 1);
  const growthPercentage = previousMonthCuts > 0 
    ? Math.round(((currentMonthCuts - previousMonthCuts) / previousMonthCuts) * 100) 
    : 0;

  const getDayAppointments = (day: string) => {
    return appointments.filter(apt => apt.day === day && apt.status === 'confirmed');
  };

  const handleTogglePayment = async (id: string) => {
    if (processingIds.has(id)) return;

    setProcessingIds(prev => new Set(prev).add(id));
    try {
      await apiTogglePayment(id);
      toast.success("Status de pagamento atualizado!");
      onRefresh();
    } catch (error) {
      toast.error("Erro ao atualizar pagamento. Tente novamente.");
      console.error(error);
    } finally {
      setProcessingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(id);
        return newSet;
      });
    }
  };

  const handleCancelAppointment = async (id: string) => {
    if (processingIds.has(id)) return;
    if (!confirm("Tem certeza que deseja cancelar este agendamento?")) return;

    setProcessingIds(prev => new Set(prev).add(id));
    try {
      await apiCancelAppointment(id);
      toast.success("Agendamento cancelado com sucesso!");
      onRefresh();
    } catch (error) {
      toast.error("Erro ao cancelar agendamento. Tente novamente.");
      console.error(error);
    } finally {
      setProcessingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(id);
        return newSet;
      });
    }
  };

  const handleSendWhatsApp = (appointment: Appointment) => {
    sendWhatsApp(appointment, PIX_KEY, WHATSAPP_NUMBER);
    toast.success("Abrindo WhatsApp...");
  };

  const handleAppointmentAdded = () => {
    toast.success("Agendamento criado com sucesso!");
    onRefresh();
    setShowAddDialog(false);
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] pt-40 pb-20 px-4">
      <div className="container mx-auto">
        <div className="mb-12 flex items-center justify-between">
          <div>
            <h1 
              className="text-4xl md:text-5xl text-white mb-4"
              style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
            >
              Dashboard do Barbeiro
            </h1>
            <p className="text-xl text-white/60">
              Gerencie sua agenda e acompanhe seus resultados
            </p>
          </div>
          <Button
            onClick={onRefresh}
            variant="outline"
            className="border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10"
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Atualizar
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Total de Cortes</p>
                <p className="text-3xl text-white">{totalCuts}</p>
                <p className="text-[#25D366] text-sm mt-1">
                  {growthPercentage > 0 ? '+' : ''}{growthPercentage}% este mês
                </p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-[#EAB308]" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Faturamento</p>
                <p className="text-3xl text-white">R$ {totalRevenue.toLocaleString('pt-BR')}</p>
                <p className="text-white/60 text-sm mt-1">Apenas pagamentos confirmados</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-[#EAB308]" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Clientes Únicos</p>
                <p className="text-3xl text-white">{uniqueClients}</p>
                <p className="text-[#25D366] text-sm mt-1">Clientes diferentes</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-[#EAB308]" />
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/60 text-sm mb-2">Taxa de Ocupação</p>
                <p className="text-3xl text-white">{occupancyRate}%</p>
                <p className="text-[#EAB308] text-sm mt-1">Horário mais cheio: {busiestHour}</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-[#EAB308]" />
              </div>
            </div>
          </Card>
        </div>

        {/* Weekly Schedule */}
        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl text-white">Agenda Semanal</h2>
            <Button 
              onClick={() => setShowAddDialog(true)}
              className="bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Agendamento
            </Button>
          </div>

          <Tabs value={selectedDay} onValueChange={setSelectedDay}>
            <TabsList className="bg-[#0D0D0D] border border-[#C19A6B]/20 mb-6 w-full grid grid-cols-6">
              {weekDays.map((day) => (
                <TabsTrigger
                  key={day}
                  value={day}
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#C19A6B] data-[state=active]:to-[#EAB308] data-[state=active]:text-[#0D0D0D]"
                >
                  {day.slice(0, 3)}
                </TabsTrigger>
              ))}
            </TabsList>

            {weekDays.map((day) => (
              <TabsContent key={day} value={day} className="space-y-3">
                {timeSlots.map((time) => {
                  const appointment = getDayAppointments(day).find(apt => apt.time === time);
                  const isProcessing = appointment && processingIds.has(appointment._id || '');
                  
                  return (
                    <div
                      key={time}
                      className={`p-4 rounded-lg border transition-all ${
                        appointment
                          ? 'bg-gradient-to-r from-[#C19A6B]/10 to-[#EAB308]/10 border-[#EAB308]/30'
                          : 'bg-[#0D0D0D] border-[#C19A6B]/10 hover:border-[#C19A6B]/30'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                          <span className="text-[#EAB308] min-w-[60px]">{time}</span>
                          {appointment ? (
                            <div className="flex-1">
                              <p className="text-white">{appointment.client}</p>
                              <p className="text-white/60 text-sm">{appointment.service} - R$ {appointment.value}</p>
                            </div>
                          ) : (
                            <span className="text-white/40">Disponível</span>
                          )}
                        </div>
                        {appointment && (
                          <div className="flex items-center gap-2">
                            <Button
                              onClick={() => handleTogglePayment(appointment._id || '')}
                              disabled={isProcessing}
                              className={`${
                                appointment.paid
                                  ? 'bg-[#25D366] hover:bg-[#25D366]/90 text-white'
                                  : 'bg-[#DC2626] hover:bg-[#DC2626]/90 text-white'
                              } rounded-full px-4 py-1 h-8`}
                            >
                              {appointment.paid ? '✓ Pago' : '✗ Não Pago'}
                            </Button>
                            <Button
                              onClick={() => handleSendWhatsApp(appointment)}
                              variant="outline"
                              className="border-[#25D366] text-[#25D366] hover:bg-[#25D366]/10 rounded-full px-4 py-1 h-8"
                            >
                              WhatsApp
                            </Button>
                            <Button
                              onClick={() => handleCancelAppointment(appointment._id || '')}
                              disabled={isProcessing}
                              variant="outline"
                              className="border-[#DC2626] text-[#DC2626] hover:bg-[#DC2626]/10 rounded-full px-4 py-1 h-8"
                            >
                              Cancelar
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </TabsContent>
            ))}
          </Tabs>
        </Card>

        {/* Recent Appointments Table */}
        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-6">
          <h2 className="text-2xl text-white mb-6">Agendamentos Recentes</h2>
          {appointments.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-16 h-16 text-white/20 mx-auto mb-4" />
              <p className="text-white/60">Nenhum agendamento cadastrado</p>
              <Button 
                onClick={() => setShowAddDialog(true)}
                className="mt-4 bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90"
              >
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeiro Agendamento
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-[#C19A6B]/20 hover:bg-transparent">
                  <TableHead className="text-[#EAB308]">Cliente</TableHead>
                  <TableHead className="text-[#EAB308]">Serviço</TableHead>
                  <TableHead className="text-[#EAB308]">Dia</TableHead>
                  <TableHead className="text-[#EAB308]">Horário</TableHead>
                  <TableHead className="text-[#EAB308]">Valor</TableHead>
                  <TableHead className="text-[#EAB308]">Pagamento</TableHead>
                  <TableHead className="text-[#EAB308]">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {appointments.slice(0, 10).map((apt) => {
                  const isProcessing = processingIds.has(apt._id || '');
                  return (
                    <TableRow key={apt._id} className="border-[#C19A6B]/10 hover:bg-[#C19A6B]/5">
                      <TableCell className="text-white">{apt.client}</TableCell>
                      <TableCell className="text-white/80">{apt.service}</TableCell>
                      <TableCell className="text-white/80">{apt.day}</TableCell>
                      <TableCell className="text-white/80">{apt.time}</TableCell>
                      <TableCell className="text-white/80">R$ {apt.value}</TableCell>
                      <TableCell>
                        <Button
                          onClick={() => handleTogglePayment(apt._id || '')}
                          disabled={isProcessing}
                          className={`${
                            apt.paid
                              ? 'bg-[#25D366] hover:bg-[#25D366]/90 text-white'
                              : 'bg-[#DC2626] hover:bg-[#DC2626]/90 text-white'
                          } rounded-full px-4 py-1 h-8`}
                        >
                          {apt.paid ? '✓ Pago' : '✗ Não Pago'}
                        </Button>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleSendWhatsApp(apt)}
                            variant="outline"
                            size="sm"
                            className="border-[#25D366] text-[#25D366] hover:bg-[#25D366]/10"
                          >
                            WhatsApp
                          </Button>
                          <Button
                            onClick={() => handleCancelAppointment(apt._id || '')}
                            disabled={isProcessing}
                            variant="outline"
                            size="sm"
                            className="border-[#DC2626] text-[#DC2626] hover:bg-[#DC2626]/10"
                          >
                            Cancelar
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </Card>
      </div>

      {/* Add Appointment Dialog */}
      <AddAppointmentDialog
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        onAppointmentAdded={handleAppointmentAdded}
      />
    </div>
  );
}
