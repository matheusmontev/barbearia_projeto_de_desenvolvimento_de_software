import { useState } from "react";
import { Scissors, Mail, ArrowLeft, CheckCircle2 } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { toast } from "sonner@2.0.3";
import { motion } from "motion/react";

interface ForgotPasswordPageProps {
  onNavigateToLogin: () => void;
}

export function ForgotPasswordPage({ onNavigateToLogin }: ForgotPasswordPageProps) {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error("Por favor, insira seu e-mail");
      return;
    }

    // Simular envio de e-mail
    toast.success("E-mail de recuperação enviado!");
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center px-4 py-20">
        <div className="w-full max-w-md">
          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="w-20 h-20 bg-gradient-to-r from-[#25D366] to-[#25D366]/80 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <CheckCircle2 className="w-10 h-10 text-white" />
            </motion.div>

            <h1 className="text-white mb-4" style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}>
              E-mail Enviado!
            </h1>

            <p className="text-white/70 mb-6">
              Enviamos um link de recuperação para <strong className="text-[#EAB308]">{email}</strong>.
              Verifique sua caixa de entrada e spam.
            </p>

            <div className="bg-gradient-to-r from-[#C19A6B]/10 to-[#EAB308]/10 border border-[#C19A6B]/30 rounded-lg p-4 mb-6">
              <p className="text-white/80 text-sm">
                📧 O link de recuperação expira em 24 horas
              </p>
              <p className="text-white/80 text-sm mt-2">
                🔒 Por segurança, não compartilhe este link
              </p>
            </div>

            <Button
              onClick={onNavigateToLogin}
              className="w-full bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full py-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para o Login
            </Button>

            <button
              onClick={() => setIsSubmitted(false)}
              className="text-[#EAB308] hover:underline text-sm mt-4"
            >
              Não recebeu o e-mail? Reenviar
            </button>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-2xl mb-4">
            <Scissors className="w-10 h-10 text-[#0D0D0D]" />
          </div>
          <h1 
            className="text-4xl text-white mb-2"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            Recuperar Senha
          </h1>
          <p className="text-white/60">
            Insira seu e-mail para receber um link de recuperação
          </p>
        </div>

        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#EAB308]" />
                E-mail Cadastrado
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                required
              />
              <p className="text-white/40 text-xs">
                Enviaremos um link para redefinir sua senha
              </p>
            </div>

            <div className="bg-gradient-to-r from-[#C19A6B]/10 to-[#EAB308]/10 border border-[#C19A6B]/30 rounded-lg p-4">
              <p className="text-white/80 text-sm">
                💡 <strong>Dica:</strong> Verifique sua caixa de spam se não encontrar o e-mail
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full py-6"
            >
              Enviar Link de Recuperação
            </Button>

            <Button
              type="button"
              onClick={onNavigateToLogin}
              variant="outline"
              className="w-full border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10 rounded-full py-6"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para o Login
            </Button>
          </form>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-white/40 text-xs">
            Problemas para acessar sua conta?{" "}
            <a href="#" className="text-[#C19A6B] hover:underline">
              Entre em contato com o suporte
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
