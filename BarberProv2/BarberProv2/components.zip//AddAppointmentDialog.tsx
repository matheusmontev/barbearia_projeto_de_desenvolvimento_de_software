import { useState } from "react";
import { Calendar, Clock, User, Scissors, DollarSign, MessageSquare, Check } from "lucide-react";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { toast } from "sonner@2.0.3";
import { motion } from "motion/react";
import { createAppointment, serviceValues, type Appointment } from "../services/api";

interface AddAppointmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAppointmentAdded?: () => void;
}

const services = [
  { id: "Corte", name: "Corte Tradicional", value: 40, duration: "30 min" },
  { id: "Corte + Barba", name: "Corte + Barba", value: 60, duration: "45 min" },
  { id: "Barba", name: "Barba", value: 30, duration: "25 min" },
  { id: "Corte Premium", name: "Corte Premium", value: 80, duration: "60 min" },
];

const weekDays = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];

const timeSlots = [
  "09:00", "10:00", "11:00", "12:00",
  "14:00", "15:00", "16:00", "17:00", "18:00"
];

// Safe way to access env variables with fallback
const getEnvVar = (key: string, defaultValue: string): string => {
  try {
    return import.meta?.env?.[key] || defaultValue;
  } catch {
    return defaultValue;
  }
};

// Configuration - Can be updated via .env file
const PIX_KEY = getEnvVar('VITE_PIX_KEY', 'seuemail@gmail.com');
const WHATSAPP_NUMBER = getEnvVar('VITE_WHATSAPP_NUMBER', '+5511987654321');

export function AddAppointmentDialog({ open, onOpenChange, onAppointmentAdded }: AddAppointmentDialogProps) {
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [selectedDay, setSelectedDay] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdAppointment, setCreatedAppointment] = useState<Appointment | null>(null);

  const selectedServiceData = services.find(s => s.id === selectedService);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validações
    if (!clientName.trim()) {
      toast.error("Digite o nome do cliente");
      return;
    }
    
    if (!clientPhone.trim()) {
      toast.error("Digite o telefone do cliente");
      return;
    }
    
    if (!selectedService) {
      toast.error("Selecione um serviço");
      return;
    }
    
    if (!selectedDay) {
      toast.error("Selecione o dia da semana");
      return;
    }
    
    if (!selectedTime) {
      toast.error("Selecione o horário");
      return;
    }
    
    if (!selectedServiceData) {
      toast.error("Serviço inválido");
      return;
    }

    setIsSubmitting(true);
    
    try {
      const appointmentData = {
        client: clientName.trim(),
        service: selectedService,
        time: selectedTime,
        day: selectedDay,
        status: 'confirmed' as const,
        paid: false,
        value: selectedServiceData.value,
        phone: clientPhone.trim()
      };

      const appointment = await createAppointment(appointmentData);
      setCreatedAppointment(appointment);
      toast.success("Agendamento criado com sucesso!");
    } catch (error) {
      console.error('Error creating appointment:', error);
      const errorMessage = error instanceof Error ? error.message : "Erro ao criar agendamento. Tente novamente.";
      toast.error(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsApp = () => {
    if (!createdAppointment) return;

    const message = `🔥 *AGENDAMENTO CONFIRMADO* 🔥

👤 *Cliente:* ${createdAppointment.client}
✂️ *Serviço:* ${createdAppointment.service}
📅 *Dia:* ${createdAppointment.day}
🕐 *Horário:* ${createdAppointment.time}
💰 *Valor:* R$ ${createdAppointment.value.toFixed(2)}

💳 *Pagamento via Pix:*
📱 Chave: ${PIX_KEY}

_Aguardo você! Qualquer dúvida, só chamar._`;

    const phoneNumber = clientPhone.replace(/\D/g, '');
    const whatsappUrl = `https://wa.me/55${phoneNumber}?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, '_blank');
    handleClose();
  };

  const handleClose = () => {
    setCreatedAppointment(null);
    onOpenChange(false);
    setClientName("");
    setClientPhone("");
    setSelectedService("");
    setSelectedDay("");
    setSelectedTime("");
    if (onAppointmentAdded) onAppointmentAdded();
  };

  const handleReset = () => {
    setCreatedAppointment(null);
    setClientName("");
    setClientPhone("");
    setSelectedService("");
    setSelectedDay("");
    setSelectedTime("");
  };

  if (createdAppointment) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="bg-[#1A1A1A] border-[#C19A6B]/30 text-white max-w-md" aria-describedby="confirmation-description">
          <DialogHeader>
            <div className="text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-20 h-20 bg-gradient-to-r from-[#C19A6B] to-[#EAB308] rounded-full flex items-center justify-center mx-auto mb-4"
              >
                <Check className="w-10 h-10 text-[#0D0D0D]" />
              </motion.div>
              <DialogTitle className="text-2xl text-white">Agendamento Cadastrado!</DialogTitle>
            </div>
          </DialogHeader>
          
          <div className="space-y-4 py-4" id="confirmation-description">
            <div className="bg-[#0D0D0D] p-6 rounded-lg space-y-3 border border-[#C19A6B]/20">
              <div className="flex items-start justify-between pb-3 border-b border-[#C19A6B]/20">
                <div className="flex-1">
                  <p className="text-white/50 text-sm mb-1">Cliente</p>
                  <p className="text-white">{clientName}</p>
                </div>
                <div className="text-right">
                  <p className="text-white/50 text-sm mb-1">Telefone</p>
                  <p className="text-white">{clientPhone}</p>
                </div>
              </div>

              <div>
                <p className="text-white/50 text-sm mb-1">Serviço</p>
                <p className="text-white">{selectedServiceData?.name}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-white/50 text-sm mb-1">Data</p>
                  <p className="text-white">{selectedDate?.toLocaleDateString('pt-BR')}</p>
                </div>
                <div>
                  <p className="text-white/50 text-sm mb-1">Horário</p>
                  <p className="text-white">{selectedTime}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-white/50 text-sm mb-1">Duração</p>
                  <p className="text-white">{selectedServiceData?.duration}</p>
                </div>
                <div>
                  <p className="text-white/50 text-sm mb-1">Valor</p>
                  <p className="text-[#EAB308]">R$ {selectedServiceData?.price}</p>
                </div>
              </div>

              <div className="pt-3 border-t border-[#C19A6B]/20">
                <p className="text-white/50 text-sm mb-1">Chave PIX</p>
                <p className="text-white text-sm break-all">{pixKey}</p>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <Button
                onClick={handleWhatsApp}
                className="bg-[#25D366] hover:bg-[#25D366]/90 text-white w-full py-6"
              >
                <MessageSquare className="w-5 h-5 mr-2" />
                Enviar Confirmação via WhatsApp
              </Button>
              <Button
                onClick={handleReset}
                variant="outline"
                className="border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10 w-full"
              >
                Fazer Outro Agendamento
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#1A1A1A] border-[#C19A6B]/30 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">Cadastrar Novo Agendamento</DialogTitle>
          <DialogDescription className="text-white/60">
            Preencha os dados do cliente e envie a confirmação via WhatsApp
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {/* Client Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="clientName" className="text-white flex items-center gap-2">
                <User className="w-4 h-4 text-[#EAB308]" />
                Nome do Cliente
              </Label>
              <Input
                id="clientName"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Ex: João Silva"
                className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308]"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="clientPhone" className="text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#EAB308]" />
                Telefone (WhatsApp)
              </Label>
              <Input
                id="clientPhone"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                placeholder="(11) 98765-4321"
                className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308]"
                required
              />
            </div>
          </div>

          {/* Service Selection */}
          <div className="space-y-2">
            <Label className="text-white flex items-center gap-2">
              <Scissors className="w-4 h-4 text-[#EAB308]" />
              Serviço
            </Label>
            <Select value={selectedService} onValueChange={setSelectedService} required>
              <SelectTrigger className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white focus:border-[#EAB308]">
                <SelectValue placeholder="Selecione o serviço" />
              </SelectTrigger>
              <SelectContent className="bg-[#1A1A1A] border-[#C19A6B]/30">
                {services.map((service) => (
                  <SelectItem 
                    key={service.id} 
                    value={service.id}
                    className="text-white focus:bg-[#C19A6B]/20 focus:text-white"
                  >
                    {service.name} - R$ {service.price} ({service.duration})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Day and Time */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#EAB308]" />
                Dia da Semana
              </Label>
              <Select value={selectedDay} onValueChange={setSelectedDay} required>
                <SelectTrigger className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white focus:border-[#EAB308]">
                  <SelectValue placeholder="Selecione o dia" />
                </SelectTrigger>
                <SelectContent className="bg-[#1A1A1A] border-[#C19A6B]/30">
                  {weekDays.map((day) => (
                    <SelectItem 
                      key={day} 
                      value={day}
                      className="text-white focus:bg-[#C19A6B]/20 focus:text-white"
                    >
                      {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#EAB308]" />
                Horário
              </Label>
              <Select value={selectedTime} onValueChange={setSelectedTime} required>
                <SelectTrigger className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white focus:border-[#EAB308]">
                  <SelectValue placeholder="Selecione o horário" />
                </SelectTrigger>
                <SelectContent className="bg-[#1A1A1A] border-[#C19A6B]/30 max-h-60">
                  {timeSlots.map((time) => (
                    <SelectItem 
                      key={time} 
                      value={time}
                      className="text-white focus:bg-[#C19A6B]/20 focus:text-white"
                    >
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Summary */}
          {selectedServiceData && (
            <div className="bg-gradient-to-br from-[#C19A6B]/10 to-[#EAB308]/10 border border-[#C19A6B]/30 rounded-lg p-4">
              <p className="text-white/60 text-sm mb-2">Resumo do Agendamento</p>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div>
                  <p className="text-white/50">Serviço:</p>
                  <p className="text-white">{selectedServiceData.name}</p>
                </div>
                <div>
                  <p className="text-white/50">Duração:</p>
                  <p className="text-white">{selectedServiceData.duration}</p>
                </div>
                <div>
                  <p className="text-white/50">Valor:</p>
                  <p className="text-[#EAB308]">R$ {selectedServiceData.value.toFixed(2)}</p>
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1 border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10"
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Salvando..." : "Cadastrar Agendamento"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
