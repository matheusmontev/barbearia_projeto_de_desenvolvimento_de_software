import { Scissors, LogOut, LayoutDashboard, Calendar, History, CreditCard, Menu, X } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isLoggedIn?: boolean;
  onLogout?: () => void;
}

export function Header({ currentPage, onNavigate, isLoggedIn = false, onLogout }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavigation = (page: string) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'dashboard', label: 'Agendamentos', icon: Calendar, section: 'appointments' },
    { id: 'history', label: 'Histórico', icon: History },
    { id: 'pricing', label: 'Planos', icon: CreditCard },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0D0D0D] border-b border-[#C19A6B]/30 shadow-lg shadow-[#C19A6B]/10">
      <div className="container mx-auto px-4">
        {/* Top Row - Logo and Actions */}
        <div className="h-20 flex items-center justify-between">
          <div 
            className="flex items-center gap-3 cursor-pointer"
            onClick={() => handleNavigation('home')}
          >
            <div className="bg-gradient-to-br from-[#C19A6B] to-[#EAB308] p-2.5 rounded-lg">
              <Scissors className="w-6 h-6 text-[#0D0D0D]" />
            </div>
            <span className="text-2xl text-[#C19A6B]" style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}>
              BarberPro
            </span>
          </div>

          {/* Desktop Actions */}
          <div className="flex items-center gap-4">
            {isLoggedIn ? (
              <Button
                onClick={onLogout}
                variant="outline"
                className="hidden md:flex border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10 rounded-full px-6"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            ) : (
              <Button
                onClick={() => handleNavigation('login')}
                className="hidden md:flex bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full px-6"
              >
                Entrar
              </Button>
            )}

            {/* Mobile Menu Toggle */}
            {isLoggedIn && (
              <Button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                variant="ghost"
                className="md:hidden text-[#C19A6B] hover:bg-[#C19A6B]/10"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
            )}
          </div>
        </div>

        {/* Desktop Menu - Only for Logged In Users */}
        {isLoggedIn && (
          <nav className="hidden md:flex items-center gap-2 pb-4 border-t border-[#C19A6B]/10 pt-4">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button
                  key={item.label}
                  onClick={() => handleNavigation(item.id)}
                  className={`flex items-center gap-2 px-6 py-2.5 rounded-lg transition-all ${
                    isActive 
                      ? 'bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D]'
                      : 'text-white/70 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        )}

        {/* Mobile Menu - Only for Logged In Users */}
        {isLoggedIn && mobileMenuOpen && (
          <nav className="md:hidden pb-4 border-t border-[#C19A6B]/10 pt-4">
            <div className="flex flex-col gap-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                
                return (
                  <button
                    key={item.label}
                    onClick={() => handleNavigation(item.id)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                      isActive 
                        ? 'bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D]'
                        : 'text-white/70 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
              
              <div className="border-t border-[#C19A6B]/10 my-2"></div>
              
              <button
                onClick={() => {
                  if (onLogout) onLogout();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-[#C19A6B] hover:bg-[#C19A6B]/10 transition-all"
              >
                <LogOut className="w-5 h-5" />
                <span>Sair</span>
              </button>
            </div>
          </nav>
        )}

        {/* Guest Menu - Not Logged In */}
        {!isLoggedIn && (
          <nav className="hidden md:flex items-center gap-6 pb-4 border-t border-[#C19A6B]/10 pt-4">
            <button
              onClick={() => handleNavigation('home')}
              className={`transition-colors ${
                currentPage === 'home' ? 'text-[#EAB308]' : 'text-white/70 hover:text-[#C19A6B]'
              }`}
            >
              Início
            </button>
            <button
              onClick={() => handleNavigation('pricing')}
              className={`transition-colors ${
                currentPage === 'pricing' ? 'text-[#EAB308]' : 'text-white/70 hover:text-[#C19A6B]'
              }`}
            >
              Planos
            </button>
            <button
              onClick={() => handleNavigation('contact')}
              className={`transition-colors ${
                currentPage === 'contact' ? 'text-[#EAB308]' : 'text-white/70 hover:text-[#C19A6B]'
              }`}
            >
              Contato
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
