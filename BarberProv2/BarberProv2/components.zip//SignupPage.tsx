import { useState } from "react";
import { Scissors, User, Mail, Phone, Lock, MapPin, Calendar } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Separator } from "./ui/separator";
import { toast } from "sonner@2.0.3";
import { motion } from "motion/react";

interface SignupPageProps {
  onSignup: () => void;
  onNavigateToLogin: () => void;
}

export function SignupPage({ onSignup, onNavigateToLogin }: SignupPageProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    barbershopName: "",
    city: "",
  });

  const handleGoogleSignup = () => {
    toast.success("Cadastro realizado com sucesso! Teste grátis por 7 dias ativado.");
    setTimeout(() => {
      onSignup();
    }, 1000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast.error("As senhas não coincidem!");
      return;
    }

    if (formData.password.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres!");
      return;
    }

    toast.success("Cadastro realizado com sucesso! Teste grátis por 7 dias ativado.");
    setTimeout(() => {
      onSignup();
    }, 1000);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-2xl">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-2xl mb-4">
            <Scissors className="w-10 h-10 text-[#0D0D0D]" />
          </div>
          <h1 
            className="text-4xl text-white mb-2"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            Criar Conta Gratuitamente
          </h1>
          <p className="text-white/60">
            Comece seu teste grátis de 7 dias. Sem cartão de crédito.
          </p>
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-gradient-to-r from-[#25D366]/20 to-[#25D366]/10 border border-[#25D366]/30 rounded-full"
          >
            <Calendar className="w-4 h-4 text-[#25D366]" />
            <span className="text-[#25D366] text-sm">7 dias grátis para testar todas as funcionalidades</span>
          </motion.div>
        </div>

        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
          {/* Google Signup Button */}
          <Button
            onClick={handleGoogleSignup}
            className="w-full bg-white hover:bg-white/90 text-[#0D0D0D] rounded-full py-6 mb-6"
          >
            <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Cadastrar com Google
          </Button>

          <div className="relative mb-6">
            <Separator className="bg-[#C19A6B]/20" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="bg-[#1A1A1A] px-4 text-white/40 text-sm">ou</span>
            </div>
          </div>

          {/* Signup Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white flex items-center gap-2">
                  <User className="w-4 h-4 text-[#EAB308]" />
                  Nome Completo
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleChange("name", e.target.value)}
                  placeholder="Seu nome"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#EAB308]" />
                  E-mail
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  placeholder="seu@email.com"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-white flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#EAB308]" />
                  Telefone/WhatsApp
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleChange("phone", e.target.value)}
                  placeholder="(11) 98765-4321"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="barbershopName" className="text-white flex items-center gap-2">
                  <Scissors className="w-4 h-4 text-[#EAB308]" />
                  Nome da Barbearia
                </Label>
                <Input
                  id="barbershopName"
                  value={formData.barbershopName}
                  onChange={(e) => handleChange("barbershopName", e.target.value)}
                  placeholder="Minha Barbearia"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="city" className="text-white flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#EAB308]" />
                Cidade
              </Label>
              <Input
                id="city"
                value={formData.city}
                onChange={(e) => handleChange("city", e.target.value)}
                placeholder="São Paulo - SP"
                className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#EAB308]" />
                  Senha
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleChange("password", e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                  required
                  minLength={6}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-white flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#EAB308]" />
                  Confirmar Senha
                </Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => handleChange("confirmPassword", e.target.value)}
                  placeholder="Repita sua senha"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                  required
                  minLength={6}
                />
              </div>
            </div>

            <div className="bg-gradient-to-r from-[#C19A6B]/10 to-[#EAB308]/10 border border-[#C19A6B]/30 rounded-lg p-4 mt-6">
              <p className="text-white/80 text-sm">
                ✓ 7 dias de teste grátis
              </p>
              <p className="text-white/80 text-sm">
                ✓ Sem cartão de crédito necessário
              </p>
              <p className="text-white/80 text-sm">
                ✓ Acesso completo a todas as funcionalidades
              </p>
              <p className="text-white/80 text-sm">
                ✓ Cancele quando quiser
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full py-6 mt-6"
            >
              Criar Conta e Começar Teste Grátis
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-white/60 text-sm">
              Já tem uma conta?{" "}
              <button 
                onClick={onNavigateToLogin}
                className="text-[#EAB308] hover:underline"
              >
                Fazer login
              </button>
            </p>
          </div>
        </Card>

        <p className="text-center text-white/40 text-xs mt-8">
          Ao criar uma conta, você concorda com nossos{" "}
          <a href="#" className="text-[#C19A6B] hover:underline">Termos de Uso</a>
          {" "}e{" "}
          <a href="#" className="text-[#C19A6B] hover:underline">Política de Privacidade</a>
        </p>
      </div>
    </div>
  );
}
