import { Shield, ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface PrivacyPageProps {
  onNavigate: (page: string) => void;
}

export function PrivacyPage({ onNavigate }: PrivacyPageProps) {
  return (
    <div className="min-h-screen bg-[#0D0D0D] pt-32 pb-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <Button
          onClick={() => onNavigate('home')}
          variant="ghost"
          className="text-[#C19A6B] hover:text-[#EAB308] mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Início
        </Button>

        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-lg flex items-center justify-center">
            <Shield className="w-6 h-6 text-[#0D0D0D]" />
          </div>
          <h1 
            className="text-4xl md:text-5xl text-white"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            Política de Privacidade
          </h1>
        </div>

        <p className="text-white/60 text-lg mb-8">
          Última atualização: 10 de Janeiro de 2025
        </p>

        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
          <div className="prose prose-invert max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">1. Introdução</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                O BarberPro respeita sua privacidade e está comprometido em proteger seus dados pessoais. 
                Esta Política de Privacidade explica como coletamos, usamos, compartilhamos e protegemos 
                suas informações.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">2. Informações que Coletamos</h2>
              
              <h3 className="text-xl text-white mb-3 mt-4">2.1 Informações Fornecidas por Você</h3>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li><strong className="text-[#EAB308]">Dados de Cadastro:</strong> Nome, email, telefone, endereço</li>
                <li><strong className="text-[#EAB308]">Dados de Pagamento:</strong> Informações de cobrança (processadas por serviços terceiros seguros)</li>
                <li><strong className="text-[#EAB308]">Dados de Clientes:</strong> Informações dos clientes da sua barbearia</li>
                <li><strong className="text-[#EAB308]">Dados de Agendamentos:</strong> Horários, serviços, valores</li>
              </ul>

              <h3 className="text-xl text-white mb-3 mt-4">2.2 Informações Coletadas Automaticamente</h3>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Endereço IP</li>
                <li>Tipo de navegador e dispositivo</li>
                <li>Data e hora de acesso</li>
                <li>Páginas visitadas</li>
                <li>Cookies e tecnologias similares</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">3. Como Usamos Suas Informações</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Utilizamos suas informações para:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Fornecer e melhorar nossos serviços</li>
                <li>Processar pagamentos e renovações</li>
                <li>Enviar notificações importantes sobre sua conta</li>
                <li>Responder suas solicitações de suporte</li>
                <li>Enviar atualizações e novidades (com seu consentimento)</li>
                <li>Prevenir fraudes e garantir segurança</li>
                <li>Cumprir obrigações legais</li>
                <li>Gerar estatísticas anônimas de uso</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">4. Compartilhamento de Informações</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                <strong className="text-[#EAB308]">Não vendemos seus dados pessoais.</strong> Podemos compartilhar 
                informações apenas nas seguintes situações:
              </p>
              
              <h3 className="text-xl text-white mb-3 mt-4">4.1 Provedores de Serviços</h3>
              <p className="text-white/80 leading-relaxed mb-4">
                Compartilhamos dados com empresas que nos ajudam a operar o BarberPro:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Hospedagem de servidores</li>
                <li>Processamento de pagamentos</li>
                <li>Serviços de email</li>
                <li>Análise de dados</li>
              </ul>

              <h3 className="text-xl text-white mb-3 mt-4">4.2 Requisitos Legais</h3>
              <p className="text-white/80 leading-relaxed mb-4">
                Podemos divulgar informações se exigido por lei ou para:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Cumprir processos legais</li>
                <li>Proteger nossos direitos e propriedade</li>
                <li>Prevenir fraudes ou abuso</li>
                <li>Proteger a segurança de usuários</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">5. Segurança dos Dados</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Implementamos medidas de segurança técnicas e organizacionais para proteger seus dados:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Criptografia SSL/TLS para transmissão de dados</li>
                <li>Senhas criptografadas</li>
                <li>Acesso restrito a dados pessoais</li>
                <li>Monitoramento de segurança contínuo</li>
                <li>Backups regulares</li>
                <li>Servidores seguros e confiáveis</li>
              </ul>
              <p className="text-white/80 leading-relaxed">
                <strong className="text-[#EAB308]">Importante:</strong> Nenhum método de transmissão pela Internet 
                é 100% seguro. Fazemos o possível para proteger seus dados, mas não podemos garantir segurança absoluta.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">6. Seus Direitos (LGPD)</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Conforme a Lei Geral de Proteção de Dados (LGPD), você tem o direito de:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li><strong className="text-[#EAB308]">Acesso:</strong> Confirmar se processamos seus dados</li>
                <li><strong className="text-[#EAB308]">Correção:</strong> Atualizar dados incompletos ou incorretos</li>
                <li><strong className="text-[#EAB308]">Exclusão:</strong> Solicitar a remoção de seus dados</li>
                <li><strong className="text-[#EAB308]">Portabilidade:</strong> Receber seus dados em formato estruturado</li>
                <li><strong className="text-[#EAB308]">Revogação:</strong> Retirar consentimento a qualquer momento</li>
                <li><strong className="text-[#EAB308]">Oposição:</strong> Opor-se ao processamento de dados</li>
                <li><strong className="text-[#EAB308]">Informação:</strong> Saber com quem compartilhamos seus dados</li>
              </ul>
              <p className="text-white/80 leading-relaxed">
                Para exercer esses direitos, entre em contato conosco através de: contato@barberpro.com
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">7. Cookies</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Usamos cookies para melhorar sua experiência. Tipos de cookies que utilizamos:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li><strong className="text-[#EAB308]">Essenciais:</strong> Necessários para o funcionamento do site</li>
                <li><strong className="text-[#EAB308]">Preferências:</strong> Lembram suas configurações</li>
                <li><strong className="text-[#EAB308]">Análise:</strong> Nos ajudam a entender como você usa o site</li>
              </ul>
              <p className="text-white/80 leading-relaxed">
                Você pode configurar seu navegador para recusar cookies, mas isso pode afetar funcionalidades.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">8. Retenção de Dados</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Mantemos seus dados apenas pelo tempo necessário para:
              </p>
              <ul className="list-disc list-inside text-white/80 space-y-2 mb-4">
                <li>Fornecer nossos serviços</li>
                <li>Cumprir obrigações legais</li>
                <li>Resolver disputas</li>
                <li>Fazer cumprir nossos acordos</li>
              </ul>
              <p className="text-white/80 leading-relaxed">
                Após o cancelamento da conta, excluímos seus dados em até 90 dias, exceto quando a lei exigir retenção.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">9. Menores de Idade</h2>
              <p className="text-white/80 leading-relaxed">
                O BarberPro não é destinado a menores de 18 anos. Não coletamos intencionalmente dados de menores. 
                Se soubermos que coletamos dados de um menor, excluiremos imediatamente.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">10. Links Externos</h2>
              <p className="text-white/80 leading-relaxed">
                Nosso site pode conter links para sites de terceiros. Não somos responsáveis pelas práticas de 
                privacidade desses sites. Recomendamos ler suas políticas de privacidade.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">11. Alterações nesta Política</h2>
              <p className="text-white/80 leading-relaxed">
                Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre mudanças 
                significativas por email ou através da plataforma. A data de "Última atualização" no topo indica 
                quando a política foi revisada pela última vez.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-[#EAB308] mb-4">12. Contato</h2>
              <p className="text-white/80 leading-relaxed mb-4">
                Para dúvidas sobre esta Política de Privacidade ou sobre como tratamos seus dados:
              </p>
              <ul className="list-none text-white/80 space-y-2 mb-4">
                <li><strong className="text-[#EAB308]">Email:</strong> contato@barberpro.com</li>
                <li><strong className="text-[#EAB308]">Telefone:</strong> (11) 98765-4321</li>
                <li><strong className="text-[#EAB308]">Endereço:</strong> São Paulo, SP</li>
              </ul>
              <p className="text-white/80 leading-relaxed">
                <strong className="text-[#EAB308]">Encarregado de Dados (DPO):</strong> dpo@barberpro.com
              </p>
            </section>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <Button
            onClick={() => onNavigate('home')}
            className="bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90"
          >
            Voltar ao Início
          </Button>
        </div>
      </div>
    </div>
  );
}
