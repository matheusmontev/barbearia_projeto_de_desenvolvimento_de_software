import { Scissors, Mail } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Separator } from "./ui/separator";
import { toast } from "sonner@2.0.3";

interface LoginPageProps {
  onLogin: () => void;
  onNavigateToSignup: () => void;
  onNavigateToForgotPassword: () => void;
}

export function LoginPage({ onLogin, onNavigateToSignup, onNavigateToForgotPassword }: LoginPageProps) {
  const handleGoogleLogin = () => {
    toast.success("Login realizado com sucesso!");
    setTimeout(() => {
      onLogin();
    }, 1000);
  };

  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Login realizado com sucesso!");
    setTimeout(() => {
      onLogin();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-2xl mb-4">
            <Scissors className="w-10 h-10 text-[#0D0D0D]" />
          </div>
          <h1 
            className="text-4xl text-white mb-2"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            BarberPro
          </h1>
          <p className="text-white/60">
            Acesse sua conta e gerencie sua barbearia
          </p>
        </div>

        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
          {/* Google Login Button */}
          <Button
            onClick={handleGoogleLogin}
            className="w-full bg-white hover:bg-white/90 text-[#0D0D0D] rounded-full py-6 mb-6"
          >
            <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Continuar com Google
          </Button>

          <div className="relative mb-6">
            <Separator className="bg-[#C19A6B]/20" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="bg-[#1A1A1A] px-4 text-white/40 text-sm">ou</span>
            </div>
          </div>

          {/* Email Login Form */}
          <form onSubmit={handleEmailLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">E-mail</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password" className="text-white">Senha</Label>
                <button
                  type="button"
                  onClick={onNavigateToForgotPassword}
                  className="text-[#EAB308] text-sm hover:underline"
                >
                  Esqueceu a senha?
                </button>
              </div>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] rounded-lg"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full py-6 mt-6"
            >
              <Mail className="w-4 h-4 mr-2" />
              Entrar com E-mail
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-white/60 text-sm">
              Não tem uma conta?{" "}
              <button 
                onClick={onNavigateToSignup}
                className="text-[#EAB308] hover:underline"
              >
                Criar conta gratuitamente
              </button>
            </p>
          </div>
          
          <div className="mt-4 text-center">
            <p className="text-[#25D366] text-sm">
              🎉 Teste grátis por 7 dias sem cartão de crédito
            </p>
          </div>
        </Card>

        {/* Benefits */}
        <div className="mt-8 space-y-3">
          <div className="flex items-center gap-3 text-white/60 text-sm">
            <div className="w-1.5 h-1.5 bg-[#EAB308] rounded-full" />
            <span>Gerencie sua agenda em tempo real</span>
          </div>
          <div className="flex items-center gap-3 text-white/60 text-sm">
            <div className="w-1.5 h-1.5 bg-[#EAB308] rounded-full" />
            <span>Envie lembretes automáticos via WhatsApp</span>
          </div>
          <div className="flex items-center gap-3 text-white/60 text-sm">
            <div className="w-1.5 h-1.5 bg-[#EAB308] rounded-full" />
            <span>Acompanhe relatórios de desempenho</span>
          </div>
        </div>

        <p className="text-center text-white/40 text-xs mt-8">
          Ao fazer login, você concorda com nossos{" "}
          <a href="#" className="text-[#C19A6B] hover:underline">Termos de Uso</a>
          {" "}e{" "}
          <a href="#" className="text-[#C19A6B] hover:underline">Política de Privacidade</a>
        </p>
      </div>
    </div>
  );
}
