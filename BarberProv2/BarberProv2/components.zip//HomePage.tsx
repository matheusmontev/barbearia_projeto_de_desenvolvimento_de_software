import { Calendar, Bell, BarChart3, Clock, CheckCircle2, MessageSquare } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen bg-[#0D0D0D]">
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-block px-4 py-2 bg-[#C19A6B]/10 border border-[#C19A6B]/30 rounded-full">
                <span className="text-[#EAB308] text-sm">Plataforma Exclusiva para Barbeiros</span>
              </div>
              
              <h1 
                className="text-5xl md:text-6xl lg:text-7xl text-white leading-tight"
                style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
              >
                Gerencie sua barbearia.{" "}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C19A6B] to-[#EAB308]">
                  Organize seus clientes.
                </span>
              </h1>

              <p className="text-xl text-white/70">
                Controle sua agenda, envie lembretes automáticos no WhatsApp e acompanhe o desempenho do seu negócio em um só lugar.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={() => onNavigate('login')}
                  className="bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full px-8 py-6 text-lg"
                >
                  Começar Agora
                </Button>
                <Button
                  onClick={() => onNavigate('contact')}
                  variant="outline"
                  className="border-[#C19A6B] text-[#C19A6B] hover:bg-[#C19A6B]/10 rounded-full px-8 py-6 text-lg"
                >
                  Saber Mais
                </Button>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-[#C19A6B]/20 to-[#EAB308]/20 blur-3xl rounded-full" />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZW5zJTIwYmFyYmVyc2hvcCUyMGludGVyaW9yfGVufDF8fHx8MTc2MDIwNzUyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Salão de barbearia masculino"
                className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover border border-[#C19A6B]/20"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent to-black/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 
              className="text-4xl md:text-5xl text-white mb-4"
              style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
            >
              Como Funciona
            </h2>
            <p className="text-xl text-white/60">
              Gerencie seus clientes de forma simples e profissional
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-full flex items-center justify-center mx-auto">
                <Calendar className="w-8 h-8 text-[#0D0D0D]" />
              </div>
              <div className="w-12 h-12 bg-[#C19A6B]/10 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl text-[#EAB308]" style={{ fontWeight: 700 }}>1</span>
              </div>
              <h3 className="text-xl text-white">Cadastre seus Clientes</h3>
              <p className="text-white/60">
                Adicione agendamentos manualmente no dashboard, informando nome, serviço, horário e valor.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-full flex items-center justify-center mx-auto">
                <MessageSquare className="w-8 h-8 text-[#0D0D0D]" />
              </div>
              <div className="w-12 h-12 bg-[#C19A6B]/10 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl text-[#EAB308]" style={{ fontWeight: 700 }}>2</span>
              </div>
              <h3 className="text-xl text-white">Envie pelo WhatsApp</h3>
              <p className="text-white/60">
                Com um clique, envie todos os detalhes do agendamento e a chave PIX direto para o cliente.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#C19A6B] to-[#EAB308] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8 text-[#0D0D0D]" />
              </div>
              <div className="w-12 h-12 bg-[#C19A6B]/10 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl text-[#EAB308]" style={{ fontWeight: 700 }}>3</span>
              </div>
              <h3 className="text-xl text-white">Controle Pagamentos</h3>
              <p className="text-white/60">
                Marque se o cliente já pagou e acompanhe sua agenda e faturamento em tempo real.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Para Barbearias */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 
              className="text-4xl md:text-5xl text-white mb-4"
              style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
            >
              Recursos Profissionais
            </h2>
            <p className="text-xl text-white/60">
              Tudo que você precisa para gerenciar sua barbearia
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 space-y-4 hover:border-[#EAB308]/40 transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <Calendar className="w-7 h-7 text-[#EAB308]" strokeWidth={1.5} />
              </div>
              <h3 className="text-xl text-white">Controle Automático de Agenda</h3>
              <p className="text-white/60">
                Gerencie horários, bloqueie períodos e visualize sua semana completa em um só lugar.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 space-y-4 hover:border-[#EAB308]/40 transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <Bell className="w-7 h-7 text-[#EAB308]" strokeWidth={1.5} />
              </div>
              <h3 className="text-xl text-white">Notificações no WhatsApp</h3>
              <p className="text-white/60">
                Receba alertas de novos agendamentos, cancelamentos e lembretes automáticos.
              </p>
            </Card>

            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8 space-y-4 hover:border-[#EAB308]/40 transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-7 h-7 text-[#EAB308]" strokeWidth={1.5} />
              </div>
              <h3 className="text-xl text-white">Relatórios de Desempenho</h3>
              <p className="text-white/60">
                Acompanhe métricas importantes: total de cortes, horários mais cheios e muito mais.
              </p>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <Button
              onClick={() => onNavigate('login')}
              className="bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full px-8 py-6 text-lg"
            >
              Criar Conta Grátis
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
