import { Mail, Phone, MapPin, MessageCircle, Send, Instagram, Facebook, Twitter } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { toast } from "sonner@2.0.3";

export function ContactPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Mensagem enviada com sucesso! Retornaremos em breve.");
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/5511987654321?text=Olá! Gostaria de mais informações sobre o BarberPro.', '_blank');
  };

  return (
    <div className="min-h-screen bg-[#0D0D0D] pt-40 pb-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h1 
            className="text-4xl md:text-5xl text-white mb-4"
            style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700 }}
          >
            Suporte e Contato
          </h1>
          <p className="text-xl text-white/60">
            Estamos aqui para ajudar você a gerenciar sua barbearia.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Contact Form */}
          <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
            <h2 className="text-2xl text-white mb-6">Envie uma Mensagem</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white">Nome Completo</Label>
                <Input
                  id="name"
                  placeholder="Seu nome"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308]"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">E-mail</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308]"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="text-white">Telefone</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(11) 98765-4321"
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-white">Mensagem</Label>
                <Textarea
                  id="message"
                  placeholder="Como podemos ajudar você?"
                  rows={5}
                  className="bg-[#0D0D0D] border-[#C19A6B]/30 text-white placeholder:text-white/40 focus:border-[#EAB308] resize-none"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-[#C19A6B] to-[#EAB308] text-[#0D0D0D] hover:opacity-90 rounded-full py-6"
              >
                <Send className="w-4 h-4 mr-2" />
                Enviar Mensagem
              </Button>
            </form>
          </Card>

          {/* Contact Info */}
          <div className="space-y-6">
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
              <h2 className="text-2xl text-white mb-6">Informações de Contato</h2>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-[#EAB308]" />
                  </div>
                  <div>
                    <h3 className="text-white mb-1">E-mail</h3>
                    <p className="text-white/60">contato@barberpro.com</p>
                    <p className="text-white/60">suporte@barberpro.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-[#EAB308]" />
                  </div>
                  <div>
                    <h3 className="text-white mb-1">Telefone</h3>
                    <p className="text-white/60">(11) 98765-4321</p>
                    <p className="text-white/60 text-sm">Segunda a Sexta, 9h às 18h</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-[#EAB308]" />
                  </div>
                  <div>
                    <h3 className="text-white mb-1">Endereço</h3>
                    <p className="text-white/60">Av. Paulista, 1000</p>
                    <p className="text-white/60">São Paulo, SP - CEP 01310-100</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* WhatsApp Card */}
            <Card className="bg-gradient-to-r from-[#25D366]/10 to-[#25D366]/5 border-[#25D366]/30 p-8">
              <div className="flex items-start gap-4 mb-6">
                <div className="w-12 h-12 bg-[#25D366] rounded-lg flex items-center justify-center flex-shrink-0">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-white mb-1">Atendimento via WhatsApp</h3>
                  <p className="text-white/60">
                    Fale conosco agora mesmo e tire suas dúvidas em tempo real.
                  </p>
                </div>
              </div>
              <Button
                onClick={handleWhatsApp}
                className="w-full bg-[#25D366] hover:bg-[#25D366]/90 text-white rounded-full py-6"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Abrir WhatsApp
              </Button>
            </Card>

            {/* Social Media */}
            <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
              <h3 className="text-white mb-4">Redes Sociais</h3>
              <p className="text-white/60 mb-6 text-sm">
                Siga-nos nas redes sociais e fique por dentro das novidades
              </p>
              <div className="flex gap-4">
                <a
                  href="#"
                  className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center hover:from-[#C19A6B]/30 hover:to-[#EAB308]/30 transition-all"
                >
                  <Instagram className="w-6 h-6 text-[#EAB308]" />
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center hover:from-[#C19A6B]/30 hover:to-[#EAB308]/30 transition-all"
                >
                  <Facebook className="w-6 h-6 text-[#EAB308]" />
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-gradient-to-br from-[#C19A6B]/20 to-[#EAB308]/20 rounded-lg flex items-center justify-center hover:from-[#C19A6B]/30 hover:to-[#EAB308]/30 transition-all"
                >
                  <Twitter className="w-6 h-6 text-[#EAB308]" />
                </a>
              </div>
            </Card>
          </div>
        </div>

        {/* FAQ Section */}
        <Card className="bg-gradient-to-br from-[#1A1A1A] to-[#0D0D0D] border-[#C19A6B]/20 p-8">
          <h2 className="text-2xl text-white mb-6 text-center">Perguntas Frequentes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h4 className="text-white">Como compartilho minha agenda?</h4>
              <p className="text-white/60 text-sm">
                Você recebe um link único que pode compartilhar no WhatsApp, Instagram ou qualquer rede social para seus clientes agendarem.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-white">Posso bloquear horários específicos?</h4>
              <p className="text-white/60 text-sm">
                Sim, você pode bloquear horários para clientes fixos, almoço ou qualquer compromisso pessoal diretamente no dashboard.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-white">Quanto custa usar o BarberPro?</h4>
              <p className="text-white/60 text-sm">
                Temos planos flexíveis a partir de R$ 49/mês com 14 dias de teste grátis. Entre em contato para conhecer nossos planos.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-white">Recebo notificações dos agendamentos?</h4>
              <p className="text-white/60 text-sm">
                Sim! Você recebe notificações instantâneas no WhatsApp para cada novo agendamento, cancelamento ou confirmação.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
