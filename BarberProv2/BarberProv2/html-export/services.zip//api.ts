// BarberPro API Service
// Centralized service for all API calls

// Safe way to access env variables with fallback
const getEnvVar = (key: string, defaultValue: string): string => {
  try {
    return import.meta?.env?.[key] || defaultValue;
  } catch {
    return defaultValue;
  }
};

const API_BASE_URL = getEnvVar('VITE_API_URL', 'http://localhost:3000/api');

export interface Appointment {
  _id?: string;
  id?: number;
  client: string;
  service: string;
  time: string;
  day: string;
  status: 'confirmed' | 'canceled';
  paid: boolean;
  value: number;
  phone?: string;
  createdAt?: string;
  canceledAt?: string;
}

export interface Metrics {
  totalCuts: number;
  totalRevenue: number;
  uniqueClients: number;
  occupancyRate: number;
  busiestHour: string;
  growthPercentage: number;
}

// Service values mapping
export const serviceValues: { [key: string]: number } = {
  "Corte + Barba": 60,
  "Corte Tradicional": 40,
  "Corte": 40,
  "Barba": 30,
  "Corte Premium": 80,
};

// Helper function to handle API errors
const handleResponse = async (response: Response) => {
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'Erro desconhecido' }));
    throw new Error(error.message || `HTTP Error ${response.status}`);
  }
  return response.json();
};

// GET all appointments
export const getAppointments = async (): Promise<Appointment[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/appointments`);
    return handleResponse(response);
  } catch (error) {
    // Silently fail if backend is not available (development mode)
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.info('ℹ️ Backend não disponível. Configure VITE_API_URL no .env');
      return []; // Return empty array instead of throwing
    }
    console.error('Error fetching appointments:', error);
    throw error;
  }
};

// GET appointments by status (active or canceled)
export const getAppointmentsByStatus = async (status: 'active' | 'canceled'): Promise<Appointment[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/appointments?status=${status}`);
    return handleResponse(response);
  } catch (error) {
    // Silently fail if backend is not available (development mode)
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.info(`ℹ️ Backend não disponível (${status}). Configure VITE_API_URL no .env`);
      return []; // Return empty array instead of throwing
    }
    console.error('Error fetching appointments by status:', error);
    throw error;
  }
};

// POST create new appointment
export const createAppointment = async (appointment: Omit<Appointment, '_id' | 'createdAt'>): Promise<Appointment> => {
  try {
    const response = await fetch(`${API_BASE_URL}/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(appointment),
    });
    return handleResponse(response);
  } catch (error) {
    // Better error handling for when backend is not available
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.info('ℹ️ Backend não disponível. Configure VITE_API_URL no .env para salvar agendamentos.');
      throw new Error('Backend não disponível. Para salvar agendamentos, configure a API no arquivo .env');
    }
    console.error('Error creating appointment:', error);
    throw error;
  }
};

// PUT update appointment (toggle payment status)
export const updateAppointment = async (id: string, updates: Partial<Appointment>): Promise<Appointment> => {
  try {
    const response = await fetch(`${API_BASE_URL}/appointments/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updates),
    });
    return handleResponse(response);
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.info('ℹ️ Backend não disponível. Atualizações não serão salvas.');
      throw new Error('Backend não disponível. Configure a API no arquivo .env');
    }
    console.error('Error updating appointment:', error);
    throw error;
  }
};

// PATCH toggle payment status
export const togglePaymentStatus = async (id: string): Promise<Appointment> => {
  try {
    const response = await fetch(`${API_BASE_URL}/appointments/${id}/toggle-payment`, {
      method: 'PATCH',
    });
    return handleResponse(response);
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.info('ℹ️ Backend não disponível. Status de pagamento não será salvo.');
      throw new Error('Backend não disponível. Configure a API no arquivo .env');
    }
    console.error('Error toggling payment status:', error);
    throw error;
  }
};

// DELETE cancel appointment (soft delete - marks as canceled)
export const cancelAppointment = async (id: string): Promise<Appointment> => {
  try {
    const response = await fetch(`${API_BASE_URL}/appointments/${id}/cancel`, {
      method: 'PATCH',
    });
    return handleResponse(response);
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.info('ℹ️ Backend não disponível. Cancelamento não será salvo.');
      throw new Error('Backend não disponível. Configure a API no arquivo .env');
    }
    console.error('Error canceling appointment:', error);
    throw error;
  }
};

// GET metrics
export const getMetrics = async (): Promise<Metrics> => {
  try {
    const response = await fetch(`${API_BASE_URL}/metrics`);
    return handleResponse(response);
  } catch (error) {
    console.error('Error fetching metrics:', error);
    throw error;
  }
};

// WhatsApp integration
export const sendWhatsApp = (appointment: Appointment, pixKey: string, phone: string) => {
  const message = `🔥 *AGENDAMENTO CONFIRMADO* 🔥

👤 *Cliente:* ${appointment.client}
✂️ *Serviço:* ${appointment.service}
📅 *Dia:* ${appointment.day}
🕐 *Horário:* ${appointment.time}
💰 *Valor:* R$ ${appointment.value.toFixed(2)}

💳 *Pagamento via Pix:*
📱 Chave: ${pixKey}

_Aguardo você! Qualquer dúvida, só chamar._ ✂️`;

  const whatsappUrl = `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
  window.open(whatsappUrl, '_blank');
};
